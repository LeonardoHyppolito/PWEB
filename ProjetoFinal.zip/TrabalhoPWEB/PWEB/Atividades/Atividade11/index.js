// Criando o objeto Funcionario1 usando a sintaxe literal de objeto
let Funcionario1 = {
    Matrícula: 12345,
    Nome: "João Silva",
    Função: "Analista de Dados"
};
// Criando o objeto Funcionario1 usando a função construtora Object()
let Funcionario2 = new Object();
Funcionario1.Matrícula = 54321;
Funcionario1.Nome = "Maria Oliveira";
Funcionario1.Função = "Desenvolvedora Web";
// Criando o objeto Funcionario1 usando a notação de colchetes
let Funcionario3 = {};
Funcionario1['Matrícula'] = 98765;
Funcionario1['Nome'] = "Carlos Souza";
Funcionario1['Função'] = "Gerente de Projetos";
